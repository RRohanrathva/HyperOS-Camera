package com.hyperos.camera;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.SurfaceTexture;
import android.os.Bundle;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.hyperos.camera.core.Camera2MtkEngine;

public class MainActivity extends Activity {
    private static final int PERMISSION_REQ_CODE = 1001;

    private TextureView viewfinder;
    private TextView btnMidr;
    private TextView btnAspectRatio;
    private TextView modePhotoBtn;
    private TextView modeHdrBtn;
    private FrameLayout shutterContainer;
    private View shutterPuck;

    private Camera2MtkEngine cameraEngine;
    private boolean isMidrOn = true;
    private boolean isHdrMode = true;
    private int currentAspectIndex = 0;
    private final String[] aspectRatios = {"4:3", "16:9", "FULL"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupListeners();

        cameraEngine = new Camera2MtkEngine(this);
        cameraEngine.setOnCaptureListener(new Camera2MtkEngine.OnCaptureListener() {
            @Override
            public void onInstantShutter() {
                runOnUiThread(() -> playShutterHapticAnimation());
            }

            @Override
            public void onError(String message) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
            }

            @Override
            public void onBurstCompleted(String burstId) {
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "HDR Captured (" + burstId + ") - Background Processing", Toast.LENGTH_SHORT).show();
                });
            }
        });

        checkPermissions();
    }

    private void initViews() {
        viewfinder = findViewById(R.id.viewfinder);
        btnMidr = findViewById(R.id.btn_midr);
        btnAspectRatio = findViewById(R.id.btn_aspect_ratio);
        modePhotoBtn = findViewById(R.id.mode_photo_btn);
        modeHdrBtn = findViewById(R.id.mode_hdr_btn);
        shutterContainer = findViewById(R.id.shutter_container);
        shutterPuck = findViewById(R.id.shutter_puck);
    }

    private void setupListeners() {
        // MiDR Toggle
        btnMidr.setOnClickListener(v -> {
            isMidrOn = !isMidrOn;
            updateMidrUi();
        });

        // Aspect Ratio Selector
        btnAspectRatio.setOnClickListener(v -> {
            currentAspectIndex = (currentAspectIndex + 1) % aspectRatios.length;
            btnAspectRatio.setText(aspectRatios[currentAspectIndex]);
            Toast.makeText(this, "Aspect Ratio: " + aspectRatios[currentAspectIndex], Toast.LENGTH_SHORT).show();
        });

        // Strictly 2 Photo Modes: PHOTO & HDR
        modePhotoBtn.setOnClickListener(v -> switchMode(false));
        modeHdrBtn.setOnClickListener(v -> switchMode(true));

        // Shutter Button (Instantaneous 0ms Shutter Release)
        shutterContainer.setOnClickListener(v -> {
            playShutterHapticAnimation();
            cameraEngine.triggerInstantaneousCapture(isHdrMode || isMidrOn);
        });

        viewfinder.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int width, int height) {
                startCameraIfPossible();
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int width, int height) {}

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
                cameraEngine.close();
                return true;
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {}
        });
    }

    private void startCameraIfPossible() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        SurfaceTexture st = viewfinder.getSurfaceTexture();
        if (st == null || !viewfinder.isAvailable()) return;
        try {
            android.util.Size size = cameraEngine.preparePreviewSize();
            st.setDefaultBufferSize(size.getWidth(), size.getHeight());

            // Keep the 4:3 preview undistorted in portrait
            int screenW = getResources().getDisplayMetrics().widthPixels;
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    screenW, screenW * size.getWidth() / size.getHeight());
            lp.gravity = android.view.Gravity.CENTER;
            viewfinder.setLayoutParams(lp);

            cameraEngine.startBackgroundThread();
            cameraEngine.openCamera(new Surface(st));
        } catch (Exception e) {
            Toast.makeText(this, "Camera start failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQ_CODE) {
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                startCameraIfPossible();
            } else {
                Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void switchMode(boolean hdr) {
        this.isHdrMode = hdr;
        if (hdr) {
            modeHdrBtn.setTextColor(getColor(R.color.hyperos_amber));
            modeHdrBtn.setTypeface(null, android.graphics.Typeface.BOLD);
            modePhotoBtn.setTextColor(0x99FFFFFF);
            modePhotoBtn.setTypeface(null, android.graphics.Typeface.NORMAL);
            isMidrOn = true;
            updateMidrUi();
        } else {
            modePhotoBtn.setTextColor(getColor(R.color.hyperos_amber));
            modePhotoBtn.setTypeface(null, android.graphics.Typeface.BOLD);
            modeHdrBtn.setTextColor(0x99FFFFFF);
            modeHdrBtn.setTypeface(null, android.graphics.Typeface.NORMAL);
            isMidrOn = false;
            updateMidrUi();
        }
    }

    private void updateMidrUi() {
        if (isMidrOn) {
            btnMidr.setBackgroundResource(R.drawable.pill_midr_active);
            btnMidr.setTextColor(getColor(R.color.hyperos_amber));
        } else {
            btnMidr.setBackgroundResource(R.drawable.pill_background);
            btnMidr.setTextColor(0xCCFFFFFF);
        }
    }

    private void playShutterHapticAnimation() {
        shutterPuck.animate()
                .scaleX(0.85f)
                .scaleY(0.85f)
                .setDuration(60)
                .withEndAction(() -> {
                    shutterPuck.animate()
                            .scaleX(1.0f)
                            .scaleY(1.0f)
                            .setInterpolator(new OvershootInterpolator(2.0f))
                            .setDuration(120)
                            .start();
                }).start();
    }

    private void checkPermissions() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, PERMISSION_REQ_CODE);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cameraEngine.close();
    }
}
