package com.hyperos.camera.core;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.*;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.util.Range;
import android.util.Rational;
import android.util.Size;
import android.view.Surface;
import com.hyperos.camera.pipeline.ZslRingBufferQueue;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Camera2MtkEngine {
    private static final String TAG = "Camera2MtkEngine";
    private static final float TARGET_NEGATIVE_EV = -4.0f;

    private final Context context;
    private final CameraManager cameraManager;
    private CameraDevice cameraDevice;
    private CameraCaptureSession captureSession;
    private CameraCharacteristics characteristics;

    private HandlerThread backgroundThread;
    private Handler backgroundHandler;

    private Surface previewSurface;
    private ImageReader burstImageReader;
    private ZslRingBufferQueue zslQueue;

    private Rational aeCompensationStep = new Rational(1, 3);
    private Range<Integer> aeCompensationRange;

    public interface OnCaptureListener {
        void onInstantShutter();
        void onBurstCompleted(String burstId);
    }

    private OnCaptureListener captureListener;

    public Camera2MtkEngine(Context context) {
        this.context = context;
        this.cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
    }

    public void setOnCaptureListener(OnCaptureListener listener) {
        this.captureListener = listener;
    }

    public void startBackgroundThread() {
        backgroundThread = new HandlerThread("Camera2MtkIoThread");
        backgroundThread.start();
        backgroundHandler = new Handler(backgroundThread.getLooper());
    }

    public void stopBackgroundThread() {
        if (backgroundThread != null) {
            backgroundThread.quitSafely();
            try {
                backgroundThread.join();
                backgroundThread = null;
                backgroundHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "Error stopping thread", e);
            }
        }
    }

    @SuppressLint("MissingPermission")
    public void openCamera(String cameraId, Surface surface, int width, int height) {
        this.previewSurface = surface;
        try {
            characteristics = cameraManager.getCameraCharacteristics(cameraId);
            aeCompensationStep = characteristics.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP);
            if (aeCompensationStep == null) aeCompensationStep = new Rational(1, 3);
            aeCompensationRange = characteristics.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);

            Log.i(TAG, "MTK Dimensity 7025 Ultra AE Step: " + aeCompensationStep + ", Range: " + aeCompensationRange);

            zslQueue = new ZslRingBufferQueue(width, height, 6);
            burstImageReader = ImageReader.newInstance(width, height, ImageFormat.YUV_420_888, 4);
            burstImageReader.setOnImageAvailableListener(burstImageListener, backgroundHandler);

            cameraManager.openCamera(cameraId, stateCallback, backgroundHandler);
        } catch (CameraAccessException e) {
            Log.e(TAG, "Failed to open camera", e);
        }
    }

    private final CameraDevice.StateCallback stateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(CameraDevice camera) {
            cameraDevice = camera;
            createCaptureSession();
        }

        @Override
        public void onDisconnected(CameraDevice camera) {
            camera.close();
            cameraDevice = null;
        }

        @Override
        public void onError(CameraDevice camera, int error) {
            camera.close();
            cameraDevice = null;
        }
    };

    private void createCaptureSession() {
        try {
            List<Surface> surfaces = Arrays.asList(previewSurface, zslQueue.getSurface(), burstImageReader.getSurface());
            cameraDevice.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(CameraCaptureSession session) {
                    captureSession = session;
                    startPreview();
                }

                @Override
                public void onConfigureFailed(CameraCaptureSession session) {
                    Log.e(TAG, "Session configuration failed");
                }
            }, backgroundHandler);
        } catch (CameraAccessException e) {
            Log.e(TAG, "Create session error", e);
        }
    }

    private void startPreview() {
        try {
            CaptureRequest.Builder builder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            builder.addTarget(previewSurface);
            builder.addTarget(zslQueue.getSurface());
            builder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);
            builder.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON);

            captureSession.setRepeatingRequest(builder.build(), null, backgroundHandler);
        } catch (CameraAccessException e) {
            Log.e(TAG, "Preview error", e);
        }
    }

    public void triggerInstantaneousCapture(boolean isHdr) {
        if (captureListener != null) {
            captureListener.onInstantShutter();
        }

        if (captureSession == null || cameraDevice == null) return;

        try {
            if (!isHdr) {
                // Grab directly from ZSL rolling circular buffer (0ms lag)
                Image normalFrame = zslQueue.acquireLatestFrame();
                if (normalFrame != null) {
                    saveImageToStaging(normalFrame, "IMG_" + System.currentTimeMillis() + "_0EV.yuv");
                    normalFrame.close();
                }
                return;
            }

            // MediaTek Dynamic Step Calculation for -4.0 EV
            float stepVal = (float) aeCompensationStep.getNumerator() / (float) aeCompensationStep.getDenominator();
            int index = Math.round(TARGET_NEGATIVE_EV / stepVal);
            if (aeCompensationRange != null) {
                index = Math.max(aeCompensationRange.getLower(), Math.min(aeCompensationRange.getUpper(), index));
            }

            // Atomic 2-Frame Burst (0 EV and -4.0 EV)
            CaptureRequest.Builder req0 = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            req0.addTarget(burstImageReader.getSurface());
            req0.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, 0);

            CaptureRequest.Builder reqUnder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            reqUnder.addTarget(burstImageReader.getSurface());
            reqUnder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, index);
            reqUnder.set(CaptureRequest.CONTROL_AE_LOCK, true);

            captureSession.captureBurst(Arrays.asList(req0.build(), reqUnder.build()), null, backgroundHandler);
        } catch (CameraAccessException e) {
            Log.e(TAG, "Capture burst error", e);
        }
    }

    private final List<Image> burstCollector = new ArrayList<>();
    private final ImageReader.OnImageAvailableListener burstImageListener = reader -> {
        Image img = reader.acquireNextImage();
        if (img == null) return;
        synchronized (burstCollector) {
            burstCollector.add(img);
            if (burstCollector.size() >= 2) {
                String burstId = "HDR_" + System.currentTimeMillis();
                saveImageToStaging(burstCollector.get(0), burstId + "_0EV.yuv");
                saveImageToStaging(burstCollector.get(1), burstId + "_under.yuv");
                burstCollector.get(0).close();
                burstCollector.get(1).close();
                burstCollector.clear();

                if (captureListener != null) {
                    captureListener.onBurstCompleted(burstId);
                }
            }
        }
    };

    private void saveImageToStaging(Image image, String filename) {
        File dir = new File(context.getCacheDir(), "hdr_staging");
        dir.mkdirs();
        File f = new File(dir, filename);
        try (FileOutputStream fos = new FileOutputStream(f)) {
            ByteBuffer buf = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buf.remaining()];
            buf.get(bytes);
            fos.write(bytes);
        } catch (Exception e) {
            Log.e(TAG, "Save staging error", e);
        }
    }

    public void close() {
        if (captureSession != null) captureSession.close();
        if (cameraDevice != null) cameraDevice.close();
        if (burstImageReader != null) burstImageReader.close();
        if (zslQueue != null) zslQueue.release();
        stopBackgroundThread();
    }
}
