package com.hyperos.camera.pipeline;

import android.graphics.Bitmap;
import android.graphics.Color;
import java.io.File;
import java.io.FileOutputStream;

/**
 * Computer Vision Pipeline for Dual-Exposure Highlight Recovery.
 * 
 * Specifically designed to eliminate halo lines and preserve subject skin lighting.
 */
public class HdrProcessingPipeline {

    public static Bitmap fuseDualExposure(Bitmap normalBmp, Bitmap underBmp, float highlightThreshold, float subjectProtectionStr) {
        int width = normalBmp.getWidth();
        int height = normalBmp.getHeight();

        int[] normalPixels = new int[width * height];
        int[] underPixels = new int[width * height];
        int[] outPixels = new int[width * height];

        normalBmp.getPixels(normalPixels, 0, width, 0, 0, width, height);
        underBmp.getPixels(underPixels, 0, width, 0, 0, width, height);

        float threshold = highlightThreshold;
        float denom = 255.0f - threshold;

        for (int i = 0; i < normalPixels.length; i++) {
            int np = normalPixels[i];
            int up = underPixels[i];

            int nr = (np >> 16) & 0xFF;
            int ng = (np >> 8) & 0xFF;
            int nb = np & 0xFF;

            int ur = (up >> 16) & 0xFF;
            int ug = (up >> 8) & 0xFF;
            int ub = up & 0xFF;

            // Luminance Y in ITU-R BT.601
            float y = 0.299f * nr + 0.587f * ng + 0.114f * nb;

            // Highlight Overexposure Weight (Smoothstep)
            float overWeight = 0.0f;
            if (y > threshold) {
                float t = (y - threshold) / denom;
                t = Math.max(0.0f, Math.min(1.0f, t));
                overWeight = t * t * (3.0f - 2.0f * t);
            }

            // Skin Chromaticity Isolation in YCbCr
            float cb = 128.0f - 0.168736f * nr - 0.331264f * ng + 0.5f * nb;
            float cr = 128.0f + 0.5f * nr - 0.418688f * ng - 0.081312f * nb;
            boolean isSkin = (y > 35 && y < 240 && cb >= 77 && cb <= 127 && cr >= 133 && cr <= 173);

            float subjWeight = isSkin ? 1.0f : 0.0f;

            // Intelligent Weight: Highlights replaced ONLY in non-subject regions
            float safeHighlightWeight = Math.max(0.0f, overWeight * (1.0f - subjWeight * subjectProtectionStr));

            // Motorola clean HDR tone fusion: Boost recovered highlights slightly to match scene brightness
            float boost = 1.15f;
            int jur = Math.min(255, Math.round(ur * boost));
            int jug = Math.min(255, Math.round(ug * boost));
            int jub = Math.min(255, Math.round(ub * boost));

            int fr = Math.round((1.0f - safeHighlightWeight) * nr + safeHighlightWeight * jur);
            int fg = Math.round((1.0f - safeHighlightWeight) * ng + safeHighlightWeight * jug);
            int fb = Math.round((1.0f - safeHighlightWeight) * nb + safeHighlightWeight * jub);

            outPixels[i] = (0xFF << 24) | (fr << 16) | (fg << 8) | fb;
        }

        Bitmap result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        result.setPixels(outPixels, 0, width, 0, 0, width, height);
        return result;
    }
}
