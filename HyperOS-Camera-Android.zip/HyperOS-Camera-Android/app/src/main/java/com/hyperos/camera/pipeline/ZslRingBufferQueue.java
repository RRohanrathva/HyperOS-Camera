package com.hyperos.camera.pipeline;

import android.graphics.ImageFormat;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Surface;
import java.util.concurrent.ArrayBlockingQueue;

public class ZslRingBufferQueue {
    private final HandlerThread handlerThread;
    private final ImageReader imageReader;
    private final ArrayBlockingQueue<Image> ringBuffer;
    private final Object lock = new Object();

    public ZslRingBufferQueue(int width, int height, int bufferSize) {
        this.handlerThread = new HandlerThread("ZslBufferThread");
        this.handlerThread.start();
        Handler handler = new Handler(this.handlerThread.getLooper());

        this.ringBuffer = new ArrayBlockingQueue<>(bufferSize);
        this.imageReader = ImageReader.newInstance(width, height, ImageFormat.YUV_420_888, bufferSize);
        this.imageReader.setOnImageAvailableListener(reader -> {
            Image image = reader.acquireLatestImage();
            if (image == null) return;
            synchronized (lock) {
                if (ringBuffer.remainingCapacity() == 0) {
                    Image stale = ringBuffer.poll();
                    if (stale != null) stale.close();
                }
                ringBuffer.offer(image);
            }
        }, handler);
    }

    public Surface getSurface() {
        return imageReader.getSurface();
    }

    public Image acquireLatestFrame() {
        synchronized (lock) {
            return ringBuffer.poll();
        }
    }

    public void release() {
        synchronized (lock) {
            while (!ringBuffer.isEmpty()) {
                Image img = ringBuffer.poll();
                if (img != null) img.close();
            }
        }
        imageReader.close();
        handlerThread.quitSafely();
    }
}
